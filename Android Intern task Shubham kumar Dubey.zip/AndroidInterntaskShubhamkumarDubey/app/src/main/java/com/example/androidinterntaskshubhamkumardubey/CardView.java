package com.example.androidinterntaskshubhamkumardubey;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class CardView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.card_view);




    }
}